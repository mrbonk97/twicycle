"use client";

import { useRouter } from "next/navigation";
import { RefObject, useEffect, useRef } from "react";
import { addMarker, initMap } from "./map-utils";
import { LocationType } from "@/types/type";
import { Loader2Icon } from "lucide-react";

interface Props {
  curQ?: string | undefined;
  locations: LocationType[];
  mapRef?: RefObject<naver.maps.Map | null>;
  markerRef?: RefObject<naver.maps.Marker[]>;
  open: () => void;
}

export const NaverMap = ({ curQ, locations, mapRef, markerRef, open }: Props) => {
  const router = useRouter();
  const mapDivRef = useRef<HTMLDivElement>(null);

  const handleClick = (l: LocationType) => {
    const params = new URLSearchParams({ id: l.id });
    if (curQ) params.set("q", curQ);
    router.push(`/?${params.toString()}`);
    open();
  };

  // 지도에 마커를 추가.
  useEffect(() => {
    if (!mapRef || !mapRef.current) return;

    // 기존 마커 제거
    if (markerRef) {
      markerRef.current.forEach((marker) => marker.setMap(null));
      markerRef.current = [];
    }

    locations.forEach((item) => {
      const marker = addMarker(mapRef.current!, item, false, () => handleClick(item));
      if (markerRef) markerRef.current.push(marker);
    });
  }, [locations]);

  // 지도를 초기화
  useEffect(() => {
    const script = document.getElementById("naver-map-script");
    if (!mapDivRef.current || !script) return;

    const onLoad = () => {
      const map = initMap(mapDivRef);
      if (mapRef) mapRef.current = map;

      locations.forEach((item) => {
        const marker = addMarker(map, item, false, () => handleClick(item));
        if (markerRef) markerRef.current.push(marker);
      });
    };

    if (script.getAttribute("data-loaded") === "true") {
      onLoad();
    } else {
      script.addEventListener("load", () => {
        script.setAttribute("data-loaded", "true");
        onLoad();
      });
    }
  }, []);

  return (
    <div className="fixed h-full top-0 bottom-0 left-0 sm:left-20 right-0 flex2" ref={mapDivRef}>
      <Loader2Icon className="animate-spin text-blue-400" size={96} />
    </div>
  );
};
