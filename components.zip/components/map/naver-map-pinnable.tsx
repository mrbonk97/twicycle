"use client";

import { Loader2Icon } from "lucide-react";
import { useEffect, useRef } from "react";
import { addMarker2 } from "./map-utils";

interface Props {
  setCoord: (c: string) => void;
}

export const NaverMapPinnable = ({ setCoord }: Props) => {
  const markerRef = useRef<naver.maps.Marker>(null);
  const mapRef = useRef<naver.maps.Map>(null);
  const mapDivRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const initMap = () => {
      if (!mapDivRef.current) return;

      const { naver } = window;
      if (!naver) return;

      const location = new naver.maps.LatLng(37.5850113953, 126.8205125895);

      mapRef.current = new naver.maps.Map(mapDivRef.current, {
        center: location,
        zoom: 16,
      });

      mapRef.current.addListener("click", (e) => {
        if (markerRef.current) {
          const pos = new naver.maps.LatLng(e.coord.y, e.coord.x);
          markerRef.current.setPosition(pos);
          setCoord(`lat: ${e.coord.y}, lng: ${e.coord.x}`);
        } else markerRef.current = addMarker2(mapRef.current!, e.coord.y, e.coord.x, () => {});
        setCoord(`lat: ${e.coord.y}, lng: ${e.coord.x}`);
      });
    };

    if (typeof window.naver != "undefined") initMap();
    else {
      const script = document.getElementById("naver-map-script");
      if (!script) return;

      const handleLoad = () => initMap();
      script.addEventListener("load", handleLoad);
      return () => script.removeEventListener("load", handleLoad);
    }
  }, []);

  return (
    <div className="h-full flex2" ref={mapDivRef}>
      <Loader2Icon className="animate-spin text-blue-400" size={96} />
    </div>
  );
};
