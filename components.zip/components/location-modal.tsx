import Image from "next/image";
import { LocationType } from "@/types/type";
import { X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface Props {
  location: LocationType;
  isMinimized: boolean;
  close: () => void;
}

export const LocationModal = ({ location, isMinimized, close }: Props) => {
  return (
    <Card
      className={`hidden lg:block z-10 fixed top-5 bottom-5 rounded-lg w-[450px] overflow-y-auto bg-background border-r !duration-500 
            ${isMinimized ? "left-[11.25rem]" : "left-[30.25rem]"}`}
    >
      <CardHeader>
        <CardTitle>{location.title}</CardTitle>
      </CardHeader>
      <button onClick={close} className="absolute right-2 top-3 hover:bg-secondary rounded-lg p-2">
        <X />
      </button>
      <CardContent className="mt-5">
        <Image
          src={location.image || "/images/location-placeholder.jpg"}
          alt={location.title}
          height={288}
          width={450}
          className="h-72 object-cover rounded-xl"
        />
        <section className="mt-5 py-5 border-y text-sm font-medium">
          <p className="text-center">{location.address}</p>
          <p className="mt-1 text-center">{location.location}</p>
        </section>
        <section className="text-sm">
          <h4 className="p-2 font-medium">운영시간</h4>
          <p className="p-2 text-xs">{location.businessHours}</p>
        </section>
        <section className="mt-5 border-t text-sm">
          <h4 className="p-2 font-medium">가격</h4>
          <p className="p-2 text-xs">{location.price}</p>
        </section>
        <section className="mt-5 border-t text-sm">
          <h4 className="p-2 font-medium">연락처</h4>
          <p className="p-2 text-xs">{location.contact}</p>
        </section>
      </CardContent>
    </Card>
  );
};
